import datatest


def setUpModule():
    global subject
    subject = datatest.CsvSource('users_fail.csv')


class TestUserData(datatest.DataTestCase):
    @datatest.mandatory  # <- If mandatory test fails, stop immediately!
    def test_columns(self):
        self.assertSubjectColumns(required={'user_id', 'active'})

    def test_user_id(self):
        def must_be_digit(x):
            return str(x).isdigit()
        self.assertSubjectSet('user_id', required=must_be_digit)

    def test_active(self):
        self.assertSubjectSet('active', required={'Y', 'N'})


if __name__ == '__main__':
    datatest.main()
