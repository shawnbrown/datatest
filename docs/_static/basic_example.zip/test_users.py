import datatest


def setUpModule():
    global subject
    subject = datatest.CsvSource('users.csv')  # <- Data under test.


class TestUserData(datatest.DataTestCase):
    def test_columns(self):
        self.assertSubjectColumns(required={'user_id', 'active'})

    def test_user_id(self):
        def must_be_digit(x):  # <- Helper function.
            return str(x).isdigit()
        self.assertSubjectSet('user_id', required=must_be_digit)

    def test_active(self):
        self.assertSubjectSet('active', required={'Y', 'N'})


if __name__ == '__main__':
    datatest.main()
