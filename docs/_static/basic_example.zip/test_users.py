import datatest


def setUpModule():
    global subjectData
    subjectData = datatest.CsvSource('users.csv')


class TestUserData(datatest.DataTestCase):
    def test_columns(self):
        """Check that file uses required column names."""
        required = {'user_id', 'active'}
        self.assertDataColumns(required)

    def test_user_id(self):
        """Check that 'user_id' column contains digits."""
        def required(x):  # <- Helper function.
            return x.isdigit()
        self.assertDataSet('user_id', required)

    def test_active(self):
        """Check that 'active' column contains valid codes."""
        required = {'Y', 'N'}
        self.assertDataSet('active', required)


if __name__ == '__main__':
    datatest.main()
