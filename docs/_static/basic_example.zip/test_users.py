import datatest


def setUpModule():
    global subjectData
    subjectData = datatest.CsvSource('users.csv')


class TestUserData(datatest.DataTestCase):
    def test_columns(self):
        """Check that file uses required column names."""
        self.assertDataColumns(required={'user_id', 'active'})

    def test_user_id(self):
        """Check that 'user_id' column contains digits."""
        def must_be_digit(x):  # <- Helper function.
            return str(x).isdigit()
        self.assertDataSet('user_id', required=must_be_digit)

    def test_active(self):
        """Check that 'active' column contains valid codes."""
        self.assertDataSet('active', required={'Y', 'N'})


if __name__ == '__main__':
    datatest.main()
