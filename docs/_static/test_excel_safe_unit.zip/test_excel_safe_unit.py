import re
from datatest import DataTestCase, working_directory, Selector


def setUpModule():
    global mydata
    with working_directory(__file__):
        mydata = Selector('test_excel_safe.csv')


def excel_safe(value):
    """Helper function to check if *value* can be opened in Excel
    without being reformatted as a date, converted to scientific
    notation, truncated, or otherwise changed.
    """
    if re.search(r'''^(
            # Date format character combinations.
            \d{1,2}-(?:\d{1,2}|\d{4})
            | (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[ \-]\d{1,2}
            | [01]?[0-9]-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)

            # Numeric conversions.
            | 0\d+.?\d*         # Number with leading zeros.
            | \d*\.\d*0         # Decimal point with trailing zeros.
            | \d*\.             # Trailing decimal point.
            | \d.?\d*E[+-]?\d+  # Scientific notation.
            | \d{16,}           # Numbers of 16+ digits get approximated.

            # Whitespace normalization.
            | \s.*              # Leading whitespace.
            | .*\s              # Trailing whitespace.
            | .*\s\s.*          # Irregular whitespace (for Office 365).

            # Other conversions
            | =.+               # Spreadsheet formula.

    )$''', str(value), re.VERBOSE | re.IGNORECASE):
        return False
    return True


class TestMyData(DataTestCase):
    def test_wellformed_a(self):
        self.assertValid(mydata('A'), excel_safe)

    def test_wellformed_b(self):
        self.assertValid(mydata('B'), excel_safe)  # Raises two invalid values.


if __name__ == '__main__':
    from datatest import main
    main()
