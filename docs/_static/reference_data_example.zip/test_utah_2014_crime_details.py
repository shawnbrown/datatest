import datatest


def setUpModule():
    global subject
    global reference
    subject = datatest.CsvSource('utah_2014_crime_details.csv')
    reference = datatest.CsvSource('utah_2014_crime_summary.csv')


class TestDetails(datatest.DataTestCase):
    def test_columns(self):
        """Check that column names match those in reference data."""
        with self.allowExtra():
            self.assertSubjectColumns()

    def test_county(self):
        """Check that 'county' column matches reference data."""
        self.assertSubjectSet('county')

    def test_incidents(self):
        """Check that sum of 'incidents' (grouped by 'county') matches
        reference data."""
        self.assertSubjectSum('incidents', keys=['county'])


if __name__ == '__main__':
    datatest.main()
